package com.Ram.ProjectManagementSystem.Repository;

import com.Ram.ProjectManagementSystem.modal.Project;
import com.Ram.ProjectManagementSystem.modal.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProjectRepository extends JpaRepository<Project, Long> {
    List<Project> findByTeamContainingOrOwner(User user, User owner);
    List<Project> findByNameContainingAndTeamConteins(String partialName,User user);
}
