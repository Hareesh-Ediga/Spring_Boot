package com.Ram.ProjectManagementSystem.Service;

import com.Ram.ProjectManagementSystem.Repository.ChatRepository;
import com.Ram.ProjectManagementSystem.modal.Chat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChatServiceImpl implements ChatService {

    @Autowired
    private ChatRepository chatRepository;

    @Override
    public Chat createChat(Chat chat) {
        return chatRepository.save(chat);
    }
}
