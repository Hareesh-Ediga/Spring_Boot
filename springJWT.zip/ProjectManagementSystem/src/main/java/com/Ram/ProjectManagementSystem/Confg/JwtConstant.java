package com.Ram.ProjectManagementSystem.Confg;

public class JwtConstant {
    public static final String SECRET_KEY = "your-256-bit-secret-your-256-bit-secret-"; // Replace this with a 32-byte key
    public static final String JWT_HEADER = "Authorization";
}
