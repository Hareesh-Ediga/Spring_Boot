package com.haree.user.Controller;

import com.haree.user.Repository.MySqlRepository;
import com.haree.user.model.user;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TestController {

    @GetMapping("/")
    public String getHome()
    {
        return "Home";
    }

    @GetMapping("/t")
    public String getest()
    {
        return "test";
    }

    @GetMapping("/person")
    public person getPerson()
    {
        person p = new person();
        p.setName("Hareesh");
        p.setAge(40);
        return p;
    }
//    @Autowired
//    private MySqlRepository mySqlRepository;
//
//    @GetMapping("/get-all-users")
//    public List<user> getAllUsers() {
//        return mySqlRepository.findAll();
//    }

}
class person{
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
