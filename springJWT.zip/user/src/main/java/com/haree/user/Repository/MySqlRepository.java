package com.haree.user.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.haree.user.model.user;
import org.springframework.stereotype.Repository;

@Repository
public interface MySqlRepository extends JpaRepository<user, Integer> {
}
