package com.hareesh.springJWT.modle;

public enum Role {

    USER,
    ADMIN
}
