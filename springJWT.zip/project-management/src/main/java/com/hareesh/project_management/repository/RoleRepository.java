//package com.hareesh.project_management.repository;
//
//import com.hareesh.project_management.entity.Role;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface RoleRepository extends JpaRepository<Role, Long> {
//}
//
