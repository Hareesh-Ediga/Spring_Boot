package com.hareesh.trialproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrialprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
