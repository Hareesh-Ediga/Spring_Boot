package com.haree.user.Controller;

import com.haree.user.model.user;
import com.haree.user.Repository.MySqlRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;


@RestController
public class UserController {

    @Autowired
    MySqlRepository mySqlRepository;

    @GetMapping("/get-all-user")
    public List<user> getAllAddresses(){

        return mySqlRepository.findAll();
    }

    @GetMapping("/get-all-user/{Id}")
    public user getSingleUser(@PathVariable("Id") Integer id){
        return mySqlRepository.findById(id).get();
    }

    @DeleteMapping("/remove/{Id}")
    public boolean deleteRow(@PathVariable("Id") Integer Id){
        if(!mySqlRepository.findById(Id).equals(Optional.empty())){
            mySqlRepository.deleteById(Id);
            return true;
        }
        return false;
    }

    @PutMapping("/update/{id}")
    public user updateAddress(@PathVariable("id") Integer id,
                                 @RequestBody Map<String, String> body){

        user current = mySqlRepository.findById(id).get();
        current.setName(body.get("name"));
        current.setAge(body.get("age"));
        current.setUsercol(body.get("usercol"));
        mySqlRepository.save(current);
        return current;
    }

    @PostMapping("/add")
    public user create(@RequestBody Map<String, String> body){

        String name = body.get("name");
        String age = body.get("age");
        String  usercol  = body.get("usercol");
        user newAddress = new user(name, age, usercol);

        return mySqlRepository.save(newAddress);
    }
}