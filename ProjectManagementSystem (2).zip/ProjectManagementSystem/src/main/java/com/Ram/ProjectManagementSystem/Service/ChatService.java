package com.Ram.ProjectManagementSystem.Service;

import com.Ram.ProjectManagementSystem.modal.Chat;

public interface ChatService {
    Chat createChat(Chat chat);
}
