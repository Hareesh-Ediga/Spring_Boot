package com.Ram.ProjectManagementSystem.Repository;

import com.Ram.ProjectManagementSystem.modal.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
}
