package com.Ram.ProjectManagementSystem.modal;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Comments;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Issue {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Id;

    private String title;
    private String description;
    private String Status;
    private String projectID;
    private String priority;
    private LocalDate dueDate;
    private List<String> tags=new ArrayList<>();



    @ManyToOne
    private com.Ram.ProjectManagementSystem.modal.User assignee;

    @ManyToOne
    private Project project;

    @JsonIgnore
    @OneToMany(mappedBy = "issue",cascade =CascadeType.ALL,orphanRemoval = true)
    private List<Comment> comments=new ArrayList<>();


}
