package com.Ram.ProjectManagementSystem.Repository;

import com.Ram.ProjectManagementSystem.modal.Chat;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ChatRepository extends JpaRepository<Chat,Long> {
}