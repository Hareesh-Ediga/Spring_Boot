package com.haree.SpringMVCboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvCbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvCbootApplication.class, args);
	}

}
