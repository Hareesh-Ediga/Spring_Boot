package com.haree.SpringMVCboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvCbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
