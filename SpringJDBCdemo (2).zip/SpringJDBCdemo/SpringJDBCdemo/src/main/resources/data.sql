insert into alien(id,name,tech) values (101,'Amoda','AIML');
insert into alien(id,name,tech) values (102,'Giri J','Benssess');
insert into alien(id,name,tech) values (103,'Charan p','React');
insert into alien(id,name,tech) values (104,'Anirudh N A','Flutter');