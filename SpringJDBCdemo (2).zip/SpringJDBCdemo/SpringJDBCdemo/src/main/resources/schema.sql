create table alien(
    id int primary key,
    name varchar(50),
    tech varchar(20)
);